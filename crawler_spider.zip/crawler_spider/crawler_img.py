import os
import requests
from baidu_img import Baidu_Consumer, Baidu_GetUrls, Baidu_Producer
from sougou_img import Sougou_Consumer, Sougou_GetUrls, Sougou_Producer
from biying_img import Biying_Consumer, Biying_GetUrls, Biying_Producer

class Crawler():
    def __init__(self, num, keyword, engine):
        self.num = num
        self.keyword = keyword
        self.engine = engine

    def down_imgs(self):
        if self.engine == 'baidu':
            page_link = Baidu_GetUrls(self.num, self.keyword)
            for x in range(5):
                Baidu_Producer().start()
            # 5个消费者线程，去从中提取下载链接，然后下载
            for x in range(5):
                Baidu_Consumer().start()
        elif self.engine == 'sougou':
            page_link = Sougou_GetUrls(self.num, self.keyword)
            for x in range(5):
                Sougou_Producer().start()
            # 5个消费者线程，去从中提取下载链接，然后下载
            for x in range(5):
                Sougou_Consumer().start()
        elif self.engine == 'biying':
            page_link = Biying_GetUrls(self.num, self.keyword)
            for x in range(5):
                Biying_Producer().start()
            # 10个消费者线程，去从中提取下载链接，然后下载
            for x in range(5):
                Biying_Consumer().start()
        else:
            print('错误的搜索引擎，请重新运行，输入：baidu、sougou、biying')

if __name__ == '__main__':
    keyword = str(input('请搜索关键词：（如：美女）'))
    num = int(input('请输入爬取图片数目：'))
    engine = str(input('请输入：baidu, sougou, biying其中之一'))
    # os.mkdir('./images')
    if os.path.exists('./images'):
        pass
    else:
        os.makedirs('./images')
    crawler = Crawler(num, keyword, engine)
    crawler.down_imgs()

